# Reinforcement Learning Game from Scratch (AIE322)

Tabular Dynamic Programming, Temporal Difference, and Policy-Gradient RL,
all trained and compared on the same 8x8 Gridworld environment.

## How to run

```
pip install -r requirements.txt

python train_and_compare.py   # trains all three algorithms, writes plots + results.csv
```

To watch an agent play, or see the greedy policy drawn as arrows, open a
Python shell (these open a pygame window, so run them directly, not
through train_and_compare.py):

```python
from environment import GridWorld
from value_iteration import value_iteration
from visualize import play_episode, render_policy_arrows

env = GridWorld()
policy, V, log, t = value_iteration(env)

play_episode(env, policy)                                   # watch the agent
render_policy_arrows(env, policy, save_path="arrows.png")   # draw the policy
```

`play_episode` and `render_policy_arrows` work with any of the three
policies returned by `value_iteration`, `train_q_learning`, or
`train_reinforce` — they're all plain `dict[state] -> action`.

## File overview

| File                  | Contents                                                                 |
|-----------------------|---------------------------------------------------------------------------|
| `environment.py`      | The Gridworld MDP: layout, transition/reward model, pygame rendering.    |
| `value_iteration.py`  | Dynamic Programming: tabular Value Iteration using the exposed model.    |
| `q_learning.py`       | Temporal Difference: tabular Q-Learning, epsilon-greedy.                 |
| `reinforce.py`        | Policy gradient: REINFORCE with a tabular softmax policy.                |
| `visualize.py`        | Pygame episode playback / policy arrows, and matplotlib comparison plots.|
| `train_and_compare.py`| Trains all three algorithms, writes plots and `results.csv`.             |

## Environment description

An 8x8 grid, hardcoded layout (see `environment.py` for exact cell
coordinates):

- **Static walls** (10 cells) block movement; walking into one, or off
  the edge of the grid, leaves the agent in place.
- **3 collectibles** each give +10 the first time the agent steps onto
  them.
- **1 terminal goal** gives +100 and ends the episode.
- **1 dynamic obstacle** patrols a fixed 4-cell loop, advancing one cell
  every timestep regardless of the agent's action. Colliding with it
  (stepping onto its current cell) gives -50. Every step also costs -1.
  Episodes end at the goal or after 200 steps.
- **Actions**: up / down / left / right, deterministic.

**State** = `(row, col, collected_mask, obstacle_phase)`. The
collectible bitmask and obstacle phase are part of the state, not just
the grid layout, because without them the process isn't Markovian: the
same cell can be safe or deadly depending on the obstacle's position in
its cycle, and collectibles that are already gone shouldn't be worth
picking up again. Leaving them out would make Value Iteration's Bellman
equation wrong and would let a trained agent loop forever chasing
rewards that no longer exist.

This gives 54 non-wall cells x 8 collectible-bitmask combinations x 4
obstacle phases = **1,728 enumerable states**, small enough for exact
Dynamic Programming, and shared unmodified by all three algorithms so
the comparison between them is meaningful.

The full model is exposed via `GridWorld.next_state_reward(s, a)`
(deterministic, so it fully determines both P(s'|s,a) and R(s,a,s')),
plus thin wrappers `transition_prob(s, a, s')` and `reward_fn(s, a, s')`
for callers that want the explicit P/R functional form.

## Notes on the comparison plots

Value Iteration is not episodic — it has sweeps, not episodes — so on
the reward-vs-episode and steps-vs-episode plots it is drawn as a
horizontal dashed reference line (its evaluated optimal reward / step
count) rather than a curve, while Q-Learning and REINFORCE are drawn as
moving-average curves over training episodes. The convergence plot
shows Value Iteration's max per-sweep value delta (log scale) side by
side with Q-Learning's and REINFORCE's moving-average reward curves.

## Results (from a training run)

| algorithm      | final_avg_reward | steps_to_goal | training_time_sec | convergence_point |
|----------------|-------------------|----------------|---------------------|----------------------|
| ValueIteration | 106.0             | 14             | 0.41                | 16 sweeps            |
| QLearning      | 105.17            | 14             | 6.6                 | ~3890 episodes       |
| REINFORCE      | 82.9              | 27             | ~62                 | ~5275 episodes       |

Q-Learning reaches essentially the same greedy-policy reward as the
optimal Value Iteration policy. Tabular REINFORCE converges to a valid
but noticeably weaker policy — expected given it only has a
mean-return baseline (no state-dependent value function) to reduce the
variance of its gradient estimate, not a bug.
