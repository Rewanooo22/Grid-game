"""Gridworld environment for the AIE322 RL-from-scratch project.

An 8x8, fully deterministic gridworld with static walls, collectible
rewards, a terminal goal, and one dynamic obstacle that patrols a fixed,
deterministic cycle. Because the obstacle's motion is a pure function of
a phase counter (not of chance), the whole environment remains a known
MDP: every (state, action) pair maps to exactly one next state and
reward, so Dynamic Programming can be applied directly using the model
functions exposed below (`next_state_reward`, `transition_prob`,
`reward_fn`).

State representation
---------------------
A state is a tuple ``(row, col, collected_mask, obstacle_phase)``:
  - ``(row, col)``       : agent position.
  - ``collected_mask``   : bitmask over COLLECTIBLES, bit i = 1 once the
                            i-th collectible has been picked up.
  - ``obstacle_phase``   : index into OBSTACLE_PATH giving the dynamic
                            obstacle's current position.

Including the collectible mask and obstacle phase in the state is what
keeps the process Markovian: without them, the reward for revisiting a
cell (or the danger of a cell) would depend on history, which breaks the
Bellman equation and would make the agent loop forever trying to
re-collect items or dodge an obstacle it can no longer predict.
"""

import numpy as np
import pygame

# ----------------------------------------------------------------------
# Grid layout (hardcoded, fixed 8x8 board)
# ----------------------------------------------------------------------
GRID_SIZE = 8

UP, DOWN, LEFT, RIGHT = 0, 1, 2, 3
ACTIONS = (UP, DOWN, LEFT, RIGHT)
ACTION_NAMES = {UP: "UP", DOWN: "DOWN", LEFT: "LEFT", RIGHT: "RIGHT"}
ACTION_DELTAS = {UP: (-1, 0), DOWN: (1, 0), LEFT: (0, -1), RIGHT: (0, 1)}
ACTION_ARROWS = {UP: "^", DOWN: "v", LEFT: "<", RIGHT: ">"}

WALLS = frozenset({
    (1, 1), (1, 2), (1, 3),
    (3, 4), (3, 5), (3, 6),
    (5, 1), (5, 2), (5, 3),
    (6, 5),
})

COLLECTIBLES = ((0, 7), (4, 0), (7, 3))
COLLECTIBLE_INDEX = {pos: i for i, pos in enumerate(COLLECTIBLES)}
N_COLLECTIBLES = len(COLLECTIBLES)
N_BITMASKS = 2 ** N_COLLECTIBLES

GOAL = (7, 7)
START = (0, 0)

# Dynamic obstacle: patrols a fixed 4-cell loop, one step per env step.
# obstacle position at phase p is OBSTACLE_PATH[p % OBSTACLE_CYCLE_LEN].
OBSTACLE_PATH = ((2, 4), (2, 5), (2, 6), (2, 7))
OBSTACLE_CYCLE_LEN = len(OBSTACLE_PATH)

# ----------------------------------------------------------------------
# Rewards
# ----------------------------------------------------------------------
STEP_REWARD = -1
COLLECTIBLE_REWARD = 10
GOAL_REWARD = 100
COLLISION_PENALTY = -50
MAX_STEPS = 200

# ----------------------------------------------------------------------
# Rendering colors / sizing
# ----------------------------------------------------------------------
CELL_SIZE = 60
COLOR_BG = (245, 245, 245)
COLOR_GRID_LINE = (200, 200, 200)
COLOR_WALL = (60, 60, 60)
COLOR_COLLECTIBLE = (240, 195, 0)
COLOR_GOAL = (40, 170, 90)
COLOR_OBSTACLE = (210, 50, 50)
COLOR_AGENT = (40, 90, 220)
COLOR_ARROW = (30, 30, 30)


class GridWorld:
    """Deterministic 8x8 gridworld MDP with a known, fully enumerable model.

    Use ``next_state_reward`` / ``transition_prob`` / ``reward_fn`` for
    planning (Dynamic Programming). Use ``reset`` / ``step`` for the
    standard episodic RL interface used by Q-Learning and REINFORCE.
    """

    def __init__(self):
        """Initializes the environment and its internal episode state."""
        self.state = None
        self.steps = 0

    # -- static grid helpers ------------------------------------------------

    @staticmethod
    def in_bounds(pos):
        """Returns True if (row, col) lies inside the 8x8 grid."""
        r, c = pos
        return 0 <= r < GRID_SIZE and 0 <= c < GRID_SIZE

    @staticmethod
    def is_wall(pos):
        """Returns True if the given cell is a static wall."""
        return pos in WALLS

    @staticmethod
    def obstacle_position(phase):
        """Returns the dynamic obstacle's grid cell at a given phase."""
        return OBSTACLE_PATH[phase % OBSTACLE_CYCLE_LEN]

    @staticmethod
    def is_terminal(state):
        """Returns True if `state`'s agent position is the goal cell.

        Terminal states are absorbing: V(terminal) = 0 always, and no
        update ever bootstraps off of a value stored for them.
        """
        row, col, _, _ = state
        return (row, col) == GOAL

    # -- full model: enumeration, transition, reward -------------------------

    def enumerate_states(self):
        """Enumerates every reachable state in the MDP.

        Returns a list of ``(row, col, collected_mask, obstacle_phase)``
        tuples covering all non-wall cells, all collectible bitmasks, and
        all obstacle phases. Small enough (a few thousand states) for
        exact Dynamic Programming.
        """
        states = []
        for row in range(GRID_SIZE):
            for col in range(GRID_SIZE):
                if (row, col) in WALLS:
                    continue
                for mask in range(N_BITMASKS):
                    for phase in range(OBSTACLE_CYCLE_LEN):
                        states.append((row, col, mask, phase))
        return states

    def next_state_reward(self, state, action):
        """The environment's model: deterministic transition + reward.

        Returns ``(next_state, reward, done)`` for taking `action` in
        `state`. Since the environment is fully deterministic, this one
        function *is* the model: P(s'|s,a) is 1.0 for the returned s'
        and 0.0 for every other state.
        """
        if self.is_terminal(state):
            # Absorbing: terminal states never transition or bootstrap.
            return state, 0.0, True

        row, col, mask, phase = state
        dr, dc = ACTION_DELTAS[action]
        new_row, new_col = row + dr, col + dc

        # Walls and the grid boundary keep the agent in place.
        if not self.in_bounds((new_row, new_col)) or self.is_wall((new_row, new_col)):
            new_row, new_col = row, col

        new_phase = (phase + 1) % OBSTACLE_CYCLE_LEN
        reward = STEP_REWARD

        new_mask = mask
        pos = (new_row, new_col)
        if pos in COLLECTIBLE_INDEX:
            idx = COLLECTIBLE_INDEX[pos]
            if not (mask >> idx) & 1:
                new_mask = mask | (1 << idx)
                reward += COLLECTIBLE_REWARD

        if pos == self.obstacle_position(new_phase):
            reward += COLLISION_PENALTY

        done = False
        if pos == GOAL:
            reward += GOAL_REWARD
            done = True

        next_state = (new_row, new_col, new_mask, new_phase)
        return next_state, reward, done

    def transition_prob(self, state, action, next_state):
        """P(s'|s,a): 1.0 if `next_state` is the deterministic successor, else 0.0."""
        actual_next, _, _ = self.next_state_reward(state, action)
        return 1.0 if actual_next == next_state else 0.0

    def reward_fn(self, state, action, next_state):
        """R(s,a,s'): reward for the transition if it is the one that actually occurs."""
        actual_next, reward, _ = self.next_state_reward(state, action)
        return reward if actual_next == next_state else 0.0

    # -- episodic interface (reset/step) used by Q-Learning & REINFORCE -----

    def reset(self):
        """Resets the environment to the fixed start state and returns it."""
        self.state = (START[0], START[1], 0, 0)
        self.steps = 0
        return self.state

    def step(self, action):
        """Applies `action`, returns (next_state, reward, done).

        `done` is True either because the goal was reached, or because
        the episode hit the MAX_STEPS truncation limit.
        """
        next_state, reward, reached_goal = self.next_state_reward(self.state, action)
        self.steps += 1
        done = reached_goal or self.steps >= MAX_STEPS
        self.state = next_state
        return next_state, reward, done

    # -- pygame rendering -----------------------------------------------------

    def render(self, screen, state=None, cell_size=CELL_SIZE):
        """Draws the current (or given) state onto a pygame surface.

        Draws walls, remaining collectibles, the goal, the dynamic
        obstacle, and the agent.
        """
        if state is None:
            state = self.state
        row, col, mask, phase = state

        screen.fill(COLOR_BG)

        for r in range(GRID_SIZE):
            for c in range(GRID_SIZE):
                rect = pygame.Rect(c * cell_size, r * cell_size, cell_size, cell_size)
                pygame.draw.rect(screen, COLOR_GRID_LINE, rect, width=1)
                if (r, c) in WALLS:
                    pygame.draw.rect(screen, COLOR_WALL, rect)

        goal_rect = pygame.Rect(GOAL[1] * cell_size, GOAL[0] * cell_size, cell_size, cell_size)
        pygame.draw.rect(screen, COLOR_GOAL, goal_rect)

        for i, (cr, cc) in enumerate(COLLECTIBLES):
            if not (mask >> i) & 1:
                center = (cc * cell_size + cell_size // 2, cr * cell_size + cell_size // 2)
                pygame.draw.circle(screen, COLOR_COLLECTIBLE, center, cell_size // 4)

        obs_r, obs_c = self.obstacle_position(phase)
        obs_center = (obs_c * cell_size + cell_size // 2, obs_r * cell_size + cell_size // 2)
        pygame.draw.circle(screen, COLOR_OBSTACLE, obs_center, cell_size // 3)

        agent_center = (col * cell_size + cell_size // 2, row * cell_size + cell_size // 2)
        pygame.draw.circle(screen, COLOR_AGENT, agent_center, cell_size // 3)
