"""Policy-based RL: REINFORCE with a tabular softmax policy over state-action preferences.

No function approximation is used: the policy is a table of preferences
`theta[state_idx, action]`, one row per enumerable state. Action
probabilities come from a softmax over that row. Training is Monte-Carlo
REINFORCE with a running mean-return baseline to reduce gradient variance.
"""

import time

import numpy as np

from environment import ACTIONS, MAX_STEPS


def softmax(preferences):
    """Numerically stable softmax over a 1D array of action preferences."""
    shifted = preferences - np.max(preferences)
    exp = np.exp(shifted)
    return exp / np.sum(exp)


def train_reinforce(env, alpha=0.01, gamma=0.99, n_episodes=20000, max_steps=MAX_STEPS, seed=0):
    """Trains a tabular softmax policy with Monte-Carlo REINFORCE.

    Args:
        env: a GridWorld instance exposing reset/step/enumerate_states.
        alpha: learning rate on the action preferences.
        gamma: discount factor used for the Monte-Carlo return.
        n_episodes: number of training episodes.
        max_steps: per-episode step cap.
        seed: RNG seed for reproducibility.

    Returns:
        (policy, theta, reward_log, steps_log, training_time, state_to_idx)
    """
    rng = np.random.default_rng(seed)

    states = env.enumerate_states()
    state_to_idx = {s: i for i, s in enumerate(states)}
    n_states = len(states)
    n_actions = len(ACTIONS)
    theta = np.zeros((n_states, n_actions))

    reward_log = []
    steps_log = []

    # Running mean-return baseline: the cumulative average episode return
    # seen so far, used to center the advantage and reduce variance.
    baseline = 0.0

    start_time = time.time()
    for ep in range(n_episodes):
        s = env.reset()
        trajectory = []  # list of (state_idx, action, reward)
        done = False
        steps = 0

        while not done and steps < max_steps:
            s_idx = state_to_idx[s]
            probs = softmax(theta[s_idx])
            a = int(rng.choice(n_actions, p=probs))

            next_s, reward, done = env.step(a)
            trajectory.append((s_idx, a, reward))
            s = next_s
            steps += 1

        total_reward = sum(r for _, _, r in trajectory)
        reward_log.append(total_reward)
        steps_log.append(steps)

        # Monte-Carlo return G_t computed backward through the episode.
        returns = [0.0] * len(trajectory)
        G = 0.0
        for t in reversed(range(len(trajectory))):
            _, _, r = trajectory[t]
            G = r + gamma * G
            returns[t] = G

        # Policy gradient update at every step of the episode:
        # theta(s,:) <- theta(s,:) + alpha * (G_t - baseline) * d/dtheta[log pi(a|s)]
        # where d/dtheta[log softmax(a)] = onehot(a) - probs (the softmax score function).
        for t, (s_idx, a, _r) in enumerate(trajectory):
            probs = softmax(theta[s_idx])
            grad_log_pi = -probs
            grad_log_pi[a] += 1.0
            advantage = returns[t] - baseline
            theta[s_idx] += alpha * advantage * grad_log_pi

        # Update the running mean-return baseline with this episode's return.
        baseline += (total_reward - baseline) / (ep + 1)

    training_time = time.time() - start_time

    policy = {s: int(np.argmax(theta[state_to_idx[s]])) for s in states}
    return policy, theta, reward_log, steps_log, training_time, state_to_idx
