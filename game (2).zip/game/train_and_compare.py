"""Trains Value Iteration, Q-Learning, and REINFORCE on the same GridWorld,
then writes comparison plots and a results table (results.csv) to disk.

Run: python train_and_compare.py
"""

import csv

import numpy as np

from environment import GridWorld
from q_learning import train_q_learning
from reinforce import train_reinforce
from value_iteration import value_iteration
from visualize import plot_convergence, plot_rewards_comparison, plot_steps_to_goal

RESULTS_CSV = "results.csv"
REWARD_PLOT = "reward_comparison.png"
CONVERGENCE_PLOT = "convergence.png"
STEPS_PLOT = "steps_to_goal.png"


def evaluate_greedy_rollout(env, policy, max_steps=200):
    """Runs one deterministic rollout of `policy` from the fixed start state.

    Returns (total_reward, steps, reached_goal).
    """
    state = env.reset()
    total_reward = 0.0
    steps = 0
    done = False
    while not done and steps < max_steps:
        action = policy[state]
        state, reward, done = env.step(action)
        total_reward += reward
        steps += 1
    reached_goal = (state[0], state[1]) == (7, 7)
    return total_reward, steps, reached_goal


def find_convergence_episode(rewards, window=100, tolerance=0.05):
    """Finds the first episode whose moving-average reward is within
    `tolerance` (relative) of the final moving-average reward, i.e. the
    point training has effectively leveled off.

    Returns an episode index, or len(rewards) if it never stabilizes.
    """
    rewards = np.asarray(rewards, dtype=float)
    if len(rewards) < window:
        return len(rewards)
    kernel = np.ones(window) / window
    ma = np.convolve(rewards, kernel, mode="valid")
    final_avg = ma[-window:].mean() if len(ma) >= window else ma[-1]
    threshold = final_avg - tolerance * abs(final_avg)
    for i, value in enumerate(ma):
        if value >= threshold:
            return i + window  # offset by window since ma[0] covers rewards[0:window]
    return len(rewards)


def print_and_save_results(rows, path=RESULTS_CSV):
    """Prints the results table to console and writes it to `path` as CSV."""
    header = ["algorithm", "final_avg_reward", "steps_to_goal", "training_time_sec", "convergence_point"]

    col_widths = [max(len(header[i]), max(len(str(r[i])) for r in rows)) for i in range(len(header))]
    line = " | ".join(h.ljust(col_widths[i]) for i, h in enumerate(header))
    print(line)
    print("-" * len(line))
    for row in rows:
        print(" | ".join(str(v).ljust(col_widths[i]) for i, v in enumerate(row)))

    with open(path, "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(header)
        writer.writerows(rows)


def main():
    """Trains all three algorithms on the same GridWorld and compares them."""
    env = GridWorld()

    print("Training Value Iteration...")
    vi_policy, V, vi_log, vi_time = value_iteration(env, gamma=0.99, theta=1e-6)
    vi_reward, vi_steps, vi_reached = evaluate_greedy_rollout(env, vi_policy)
    vi_convergence = len(vi_log)
    print(f"  done: {vi_convergence} sweeps, reward={vi_reward}, steps={vi_steps}, reached_goal={vi_reached}")

    print("Training Q-Learning...")
    ql_policy, Q, ql_rewards, ql_steps_log, ql_time, _ = train_q_learning(
        env, alpha=0.1, gamma=0.99, epsilon_start=1.0, epsilon_end=0.05, n_episodes=5000
    )
    ql_reward, ql_steps, ql_reached = evaluate_greedy_rollout(env, ql_policy)
    ql_convergence = find_convergence_episode(ql_rewards)
    print(f"  done: reward={ql_reward}, steps={ql_steps}, reached_goal={ql_reached}")

    print("Training REINFORCE...")
    rf_policy, theta, rf_rewards, rf_steps_log, rf_time, _ = train_reinforce(
        env, alpha=0.01, gamma=0.99, n_episodes=20000
    )
    rf_reward, rf_steps, rf_reached = evaluate_greedy_rollout(env, rf_policy)
    rf_convergence = find_convergence_episode(rf_rewards)
    print(f"  done: reward={rf_reward}, steps={rf_steps}, reached_goal={rf_reached}")

    print("Writing plots...")
    plot_rewards_comparison(vi_reward, ql_rewards, rf_rewards, REWARD_PLOT)
    plot_convergence(vi_log, ql_rewards, rf_rewards, CONVERGENCE_PLOT)
    plot_steps_to_goal(vi_steps, ql_steps_log, rf_steps_log, STEPS_PLOT)

    rows = [
        ["ValueIteration", round(vi_reward, 2), vi_steps, round(vi_time, 4), vi_convergence],
        ["QLearning", round(float(np.mean(ql_rewards[-100:])), 2), ql_steps, round(ql_time, 4), ql_convergence],
        ["REINFORCE", round(float(np.mean(rf_rewards[-100:])), 2), rf_steps, round(rf_time, 4), rf_convergence],
    ]
    print()
    print_and_save_results(rows)


if __name__ == "__main__":
    main()
