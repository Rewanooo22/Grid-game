"""Dynamic Programming: tabular Value Iteration on the GridWorld model.

Uses the environment's exposed model (`next_state_reward`, which encodes
P(s'|s,a) and R(s,a,s') exactly, since the environment is deterministic)
to solve the Bellman optimality equation by repeated sweeps over every
enumerable state, with no sampling involved.
"""

import time

from environment import ACTIONS


def value_iteration(env, gamma=0.99, theta=1e-6, max_sweeps=100000):
    """Runs tabular Value Iteration to convergence.

    Args:
        env: a GridWorld instance exposing enumerate_states/next_state_reward/is_terminal.
        gamma: discount factor.
        theta: sweep stops once the max value change across all states drops below this.
        max_sweeps: safety cap on the number of sweeps.

    Returns:
        (policy, V, log, training_time) where `policy` maps state -> best
        action, `V` maps state -> optimal value, `log` is the list of
        max-delta values (one per sweep), and `training_time` is the
        wall-clock training time in seconds.
    """
    states = env.enumerate_states()
    V = {s: 0.0 for s in states}
    log = []

    start_time = time.time()
    for _sweep in range(max_sweeps):
        delta = 0.0
        for s in states:
            if env.is_terminal(s):
                # Terminal states are fixed at V(s) = 0 and are never updated.
                continue
            v_old = V[s]

            # Bellman optimality update: V(s) <- max_a [ R(s,a,s') + gamma * V(s') ]
            # The environment is deterministic, so the expectation over s'
            # collapses to the single successor state returned by the model.
            best_value = -float("inf")
            for a in ACTIONS:
                next_s, reward, _done = env.next_state_reward(s, a)
                next_v = 0.0 if env.is_terminal(next_s) else V[next_s]
                q_sa = reward + gamma * next_v
                if q_sa > best_value:
                    best_value = q_sa

            V[s] = best_value
            delta = max(delta, abs(v_old - V[s]))

        log.append(delta)
        if delta < theta:
            break

    training_time = time.time() - start_time
    policy = extract_greedy_policy(env, V, gamma)
    return policy, V, log, training_time


def extract_greedy_policy(env, V, gamma):
    """Extracts the greedy policy pi(s) = argmax_a [ R(s,a,s') + gamma * V(s') ]."""
    policy = {}
    for s in env.enumerate_states():
        if env.is_terminal(s):
            policy[s] = ACTIONS[0]
            continue
        best_action, best_value = ACTIONS[0], -float("inf")
        for a in ACTIONS:
            next_s, reward, _done = env.next_state_reward(s, a)
            next_v = 0.0 if env.is_terminal(next_s) else V[next_s]
            q_sa = reward + gamma * next_v
            if q_sa > best_value:
                best_value = q_sa
                best_action = a
        policy[s] = best_action
    return policy
