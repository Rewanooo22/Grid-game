"""Visualization tools: pygame policy/episode viewers, and matplotlib plots.

Three kinds of output live here:
  - `play_episode`: opens a pygame window and animates an agent following
    a given policy, so a human can watch it.
  - `render_policy_arrows`: opens a pygame window (and can save a PNG)
    showing the greedy action chosen in every free cell, drawn as an
    arrow, for a fixed collectible-mask/obstacle-phase snapshot.
  - `plot_rewards_comparison`, `plot_convergence`, `plot_steps_to_goal`:
    matplotlib figures saved to disk for the algorithm comparison.
"""

import matplotlib
matplotlib.use("Agg")  # headless: all plots are saved to disk, never shown interactively

import matplotlib.pyplot as plt
import numpy as np
import pygame

from environment import (
    ACTIONS, ACTION_ARROWS, CELL_SIZE, COLOR_ARROW, GOAL, GRID_SIZE, MAX_STEPS, WALLS,
)


def play_episode(env, policy, cell_size=CELL_SIZE, delay_ms=250):
    """Opens a pygame window and plays one episode under `policy`.

    Args:
        env: a GridWorld instance.
        policy: dict mapping state -> action.
        cell_size: pixel size of one grid cell.
        delay_ms: delay between rendered steps, in milliseconds.
    """
    pygame.init()
    screen = pygame.display.set_mode((GRID_SIZE * cell_size, GRID_SIZE * cell_size))
    pygame.display.set_caption("GridWorld - episode playback")
    clock = pygame.time.Clock()

    state = env.reset()
    env.render(screen, state, cell_size)
    pygame.display.flip()

    done = False
    steps = 0
    running = True
    while running and not done and steps < MAX_STEPS:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
        if not running:
            break

        action = policy[state]
        state, _reward, done = env.step(action)
        steps += 1

        env.render(screen, state, cell_size)
        pygame.display.flip()
        pygame.time.delay(delay_ms)

    pygame.time.delay(600)
    pygame.quit()


def render_policy_arrows(env, policy, mask=0, phase=0, cell_size=CELL_SIZE, save_path=None):
    """Draws the greedy policy as an arrow in every free cell.

    Since the policy is defined over the full state (position, mask,
    phase), this renders one fixed snapshot: `mask` (which collectibles
    are treated as already collected) and `phase` (the dynamic
    obstacle's position) are held constant across the grid.

    Args:
        env: a GridWorld instance.
        policy: dict mapping state -> action.
        mask, phase: which collectible-mask/obstacle-phase slice to draw.
        cell_size: pixel size of one grid cell.
        save_path: if given, the rendered image is saved to this path.
    """
    pygame.init()
    screen = pygame.display.set_mode((GRID_SIZE * cell_size, GRID_SIZE * cell_size))
    pygame.display.set_caption("GridWorld - greedy policy")

    dummy_state = (0, 0, mask, phase)
    env.render(screen, dummy_state, cell_size)

    font = pygame.font.SysFont("consolas", cell_size // 2, bold=True)
    for row in range(GRID_SIZE):
        for col in range(GRID_SIZE):
            if (row, col) in WALLS or (row, col) == GOAL:
                continue
            state = (row, col, mask, phase)
            action = policy[state]
            glyph = font.render(ACTION_ARROWS[action], True, COLOR_ARROW)
            rect = glyph.get_rect(
                center=(col * cell_size + cell_size // 2, row * cell_size + cell_size // 2)
            )
            screen.blit(glyph, rect)

    pygame.display.flip()
    if save_path:
        pygame.image.save(screen, save_path)
    pygame.time.delay(600)
    pygame.quit()


def moving_average(values, window=100):
    """Computes a simple moving average; returns the raw array if too short."""
    values = np.asarray(values, dtype=float)
    if len(values) < window:
        return values.copy()
    kernel = np.ones(window) / window
    return np.convolve(values, kernel, mode="valid")


def plot_rewards_comparison(vi_reward, ql_rewards, rf_rewards, save_path, window=100):
    """Plots reward vs episode (moving average) for all three algorithms.

    Value Iteration is not episodic, so its evaluated greedy-rollout
    reward is drawn as a constant reference line rather than a curve.
    """
    fig, ax = plt.subplots(figsize=(9, 6))

    ql_ma = moving_average(ql_rewards, window)
    rf_ma = moving_average(rf_rewards, window)

    ax.plot(np.arange(len(ql_ma)), ql_ma, label="Q-Learning (moving avg)", color="tab:blue")
    ax.plot(np.arange(len(rf_ma)), rf_ma, label="REINFORCE (moving avg)", color="tab:orange")
    ax.axhline(vi_reward, color="tab:green", linestyle="--",
               label=f"Value Iteration (optimal, reward={vi_reward:.1f})")

    ax.set_xlabel("Episode")
    ax.set_ylabel("Total reward")
    ax.set_title(f"Reward vs Episode (moving average, window={window})")
    ax.legend()
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_convergence(vi_log, ql_rewards, rf_rewards, save_path, window=100):
    """Plots convergence: VI's max delta per sweep, and QL/REINFORCE moving-average reward."""
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(12, 5))

    ax1.plot(np.arange(1, len(vi_log) + 1), vi_log, color="tab:green")
    ax1.set_yscale("log")
    ax1.set_xlabel("Sweep")
    ax1.set_ylabel("Max value delta (log scale)")
    ax1.set_title("Value Iteration convergence")

    ql_ma = moving_average(ql_rewards, window)
    rf_ma = moving_average(rf_rewards, window)
    ax2.plot(np.arange(len(ql_ma)), ql_ma, label="Q-Learning", color="tab:blue")
    ax2.plot(np.arange(len(rf_ma)), rf_ma, label="REINFORCE", color="tab:orange")
    ax2.set_xlabel("Episode")
    ax2.set_ylabel(f"Moving avg reward (window={window})")
    ax2.set_title("Q-Learning / REINFORCE convergence")
    ax2.legend()

    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)


def plot_steps_to_goal(vi_steps, ql_steps, rf_steps, save_path, window=100):
    """Plots steps-to-goal vs episode (moving average) for all three algorithms."""
    fig, ax = plt.subplots(figsize=(9, 6))

    ql_ma = moving_average(ql_steps, window)
    rf_ma = moving_average(rf_steps, window)

    ax.plot(np.arange(len(ql_ma)), ql_ma, label="Q-Learning (moving avg)", color="tab:blue")
    ax.plot(np.arange(len(rf_ma)), rf_ma, label="REINFORCE (moving avg)", color="tab:orange")
    ax.axhline(vi_steps, color="tab:green", linestyle="--",
               label=f"Value Iteration (optimal, steps={vi_steps})")

    ax.set_xlabel("Episode")
    ax.set_ylabel("Steps to episode end")
    ax.set_title(f"Steps-to-goal vs Episode (moving average, window={window})")
    ax.legend()
    fig.tight_layout()
    fig.savefig(save_path)
    plt.close(fig)
